# globals <- new.env(parent=emptyenv(), hash=TRUE)
# globals$have_RCurl <- require("RCurl")
